/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef MKI194V1_READ_DATA_H
#define MKI194V1_READ_DATA_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include <stdint.h>
#include <stddef.h>
#include <math.h>

void lsm6dsr_read_data_polling(void);





#ifdef __cplusplus
}
#endif

#endif /* MKI194V1_H */



